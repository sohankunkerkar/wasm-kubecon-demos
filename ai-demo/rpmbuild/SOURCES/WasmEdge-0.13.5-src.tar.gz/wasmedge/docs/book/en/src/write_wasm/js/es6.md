# ES6 module support

> This part has been moved to  <https://wasmedge.org/docs/develop/javascript/es6>. Please use our new docs.
