# Neural Network for WASI

This Part has been moved to

1. Pytorch: <https://wasmedge.org/docs/develop/rust/wasinn/pytorch>
2. OpenVINO: <https://wasmedge.org/docs/develop/rust/wasinn/openvino>
3. TensorFlow-Lite: <https://wasmedge.org/docs/develop/rust/wasinn/tensorflow_lite>

Please use our new docs.
