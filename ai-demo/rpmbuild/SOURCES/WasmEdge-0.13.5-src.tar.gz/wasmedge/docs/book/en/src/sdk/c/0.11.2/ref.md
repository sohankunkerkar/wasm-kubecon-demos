# WasmEdge C 0.11.2 API Documentation

This  part has moved to <https://wasmedge.org/docs/embed/c/reference/0.11.x>. Please use our new docs.
