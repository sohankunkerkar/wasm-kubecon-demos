# Node.js support

> This part has been moved to  <https://wasmedge.org/docs/develop/javascript/nodejs>. Please use our new docs.
