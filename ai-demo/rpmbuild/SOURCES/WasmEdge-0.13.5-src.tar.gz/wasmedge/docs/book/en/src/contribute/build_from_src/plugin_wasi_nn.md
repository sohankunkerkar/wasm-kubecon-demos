# Build WasmEdge With WASI-NN Plug-in

> This part has been moved to  <https://wasmedge.org/docs/contribute/source/plugin/wasi_nn>. Please use our new docs.
