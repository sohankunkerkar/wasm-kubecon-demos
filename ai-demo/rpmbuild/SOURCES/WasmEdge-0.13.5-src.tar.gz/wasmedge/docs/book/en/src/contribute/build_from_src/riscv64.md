# Build and test WasmEdge on RISC-V 64 arch

> This part has been moved to  <https://wasmedge.org/docs/contribute/source/os/riscv64>. Please use our new docs.
