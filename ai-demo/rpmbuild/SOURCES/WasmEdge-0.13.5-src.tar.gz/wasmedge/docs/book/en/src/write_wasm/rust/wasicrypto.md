# Crypto for WASI

> This part has been moved to  <https://wasmedge.org/docs/develop/rust/wasicrypto>. Please use our new docs.
