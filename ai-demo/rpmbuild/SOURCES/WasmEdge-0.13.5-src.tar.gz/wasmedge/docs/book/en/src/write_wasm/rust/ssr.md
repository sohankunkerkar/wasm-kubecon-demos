# Server-side rendering

> This part has been moved to <https://wasmedge.org/docs/develop/rust/ssr>. Please use our new docs.
