# Use Rust to implement JS API

> This part has been moved to  <https://wasmedge.org/docs/develop/javascript/rust>. Please use our new docs.
