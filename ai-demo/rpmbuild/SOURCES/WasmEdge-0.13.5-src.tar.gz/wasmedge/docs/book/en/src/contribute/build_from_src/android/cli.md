# WasmEdge CLI tools for Android

> This part has been moved to  <https://wasmedge.org/docs/contribute/source/os/android/cli>. Please use our new docs.
