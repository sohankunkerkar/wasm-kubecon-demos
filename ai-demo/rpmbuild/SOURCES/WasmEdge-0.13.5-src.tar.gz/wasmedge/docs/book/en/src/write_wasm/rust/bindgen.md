# Bindgen of Rust Functions

> This part has been moved to  <https://wasmedge.org/docs/develop/rust/bindgen>. Please use our new docs.
