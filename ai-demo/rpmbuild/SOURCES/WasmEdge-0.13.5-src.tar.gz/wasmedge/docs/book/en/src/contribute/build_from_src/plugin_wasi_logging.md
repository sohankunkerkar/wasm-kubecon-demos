# Build WasmEdge With WASI-Logging Plug-in

> This part has been moved to <https://wasmedge.org/docs/contribute/source/plugin/wasi_logging>. Please use our new docs.
