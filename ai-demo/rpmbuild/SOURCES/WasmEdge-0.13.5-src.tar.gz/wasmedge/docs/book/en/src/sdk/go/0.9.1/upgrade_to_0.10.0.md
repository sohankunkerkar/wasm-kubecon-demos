# Upgrade to WasmEdge-Go v0.10.0

> This part has been moved to  <https://wasmedge.org/docs/embed/go/reference/upgrade_to_0.10.0>. Please use our new docs.
