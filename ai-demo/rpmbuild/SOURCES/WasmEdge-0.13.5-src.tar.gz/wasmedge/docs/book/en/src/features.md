# WasmEdge Features

> This Part has been moved to<https://wasmedge.org/docs/start/wasmedge/features>. Please use our new docs.
