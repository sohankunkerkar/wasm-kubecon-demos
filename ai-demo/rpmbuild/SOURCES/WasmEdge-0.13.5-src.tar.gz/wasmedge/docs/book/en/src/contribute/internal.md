# WasmEdge Internal

> This part has been moved to <https://wasmedge.org/docs/contribute/internal>. Please use our new docs.
