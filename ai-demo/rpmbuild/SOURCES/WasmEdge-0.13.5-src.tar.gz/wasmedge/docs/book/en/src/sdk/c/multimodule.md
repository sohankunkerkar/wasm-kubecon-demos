# Multiple WASM Module Example

> This part has been moved to  <https://wasmedge.org/docs/embed/c/multiple_modules>. Please use our new docs.
