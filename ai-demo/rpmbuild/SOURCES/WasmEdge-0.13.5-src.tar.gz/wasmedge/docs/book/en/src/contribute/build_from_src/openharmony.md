# Build WasmEdge for Open Harmony

WIP. For Chinese speakers, please [check out this instruction](https://github.com/WasmEdge/WasmEdge/blob/master/utils/ohos/README-zh.md).
