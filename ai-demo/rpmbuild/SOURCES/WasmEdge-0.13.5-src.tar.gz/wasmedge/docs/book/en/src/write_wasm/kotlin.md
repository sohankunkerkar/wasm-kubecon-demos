# Kotlin

Check out how to [compile Kotlin programs to WebAssembly](https://blog.jdriven.com/2021/04/running-kotlin-in-the-browser-with-wasm/)
