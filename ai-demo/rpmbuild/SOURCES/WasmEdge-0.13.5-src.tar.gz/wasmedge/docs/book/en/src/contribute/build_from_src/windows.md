# Build WasmEdge on Windows 10

> This part has been moved to  <https://wasmedge.org/docs/contribute/source/os/windows>. Please use our new docs.
