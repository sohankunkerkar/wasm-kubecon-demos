# Non-blocking Networking Sockets

> This part has been moved to

1. Client example: <https://wasmedge.org/docs/develop/rust/socket_networking/client>

2. Server example: <https://wasmedge.org/docs/develop/rust/socket_networking/server/>
