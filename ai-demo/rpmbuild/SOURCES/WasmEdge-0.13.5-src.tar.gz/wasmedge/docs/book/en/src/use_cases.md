# WasmEdge Use Cases

> This part has been moved to <https://wasmedge.org/docs/start/usage/use-cases>. Please use our new docs.
