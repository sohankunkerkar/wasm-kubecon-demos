# WasmEdge Command Line Tools

> This part has been moved to <https://wasmedge.org/docs/start/build-and-run/cli>. Please use our new docs.
