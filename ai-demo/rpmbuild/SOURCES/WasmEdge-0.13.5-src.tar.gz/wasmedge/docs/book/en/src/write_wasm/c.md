# C

> This part has been moved to <https://wasmedge.org/docs/develop/c/simd>. Please use our new docs
