# Access OS services

> This part has been moved to  <https://wasmedge.org/docs/develop/rust/os>. Please use our new docs.
