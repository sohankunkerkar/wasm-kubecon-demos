# Build WasmEdge on MacOS

> This part has been moved to  <https://wasmedge.org/docs/contribute/source/os/macos>. Please use our new docs.
