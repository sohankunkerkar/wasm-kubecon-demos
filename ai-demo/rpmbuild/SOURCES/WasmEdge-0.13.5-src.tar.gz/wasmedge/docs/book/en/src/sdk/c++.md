# WasmEdge C++ SDK

> This part has been moved to <https://wasmedge.org/docs/embed/c++/intro>. Please use our new docs.