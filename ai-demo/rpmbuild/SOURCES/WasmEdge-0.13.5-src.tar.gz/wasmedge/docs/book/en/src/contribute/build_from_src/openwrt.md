# Build and test WasmEdge for OpenWrt

> This part has been moved to  <https://wasmedge.org/docs/contribute/source/os/openwrt>. Please use our new docs.
