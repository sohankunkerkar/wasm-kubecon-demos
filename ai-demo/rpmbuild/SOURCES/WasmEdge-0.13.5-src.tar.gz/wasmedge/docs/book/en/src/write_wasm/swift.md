# Swift

The [swiftwasm](https://swiftwasm.org/) project compiles Swift source code to WebAssembly.
