# Tensorflow

> This part has been moved to <https://wasmedge.org/docs/develop/rust/ai_inference/tensorflow_lite>. Please use our new docs.
