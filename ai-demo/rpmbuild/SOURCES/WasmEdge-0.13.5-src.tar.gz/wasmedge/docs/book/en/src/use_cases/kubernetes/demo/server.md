# HTTP server example

> This part has been moved to <https://github.com/second-state/wasmedge-containers-examples/blob/main/http_server_wasi_app.md>. Please use our new docs.