# WasmEdge 0.9.1 C API Documentation

> This part has been moved to  <https://wasmedge.org/docs/embed/c/reference/0.9.x>. Please use our new docs.
