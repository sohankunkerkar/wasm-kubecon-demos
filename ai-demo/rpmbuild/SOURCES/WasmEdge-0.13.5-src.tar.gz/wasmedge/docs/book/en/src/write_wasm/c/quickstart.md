# Getting Started

> This part has been moved to  <https://wasmedge.org/docs/develop/c/hello_world>. Please use our new docs.
