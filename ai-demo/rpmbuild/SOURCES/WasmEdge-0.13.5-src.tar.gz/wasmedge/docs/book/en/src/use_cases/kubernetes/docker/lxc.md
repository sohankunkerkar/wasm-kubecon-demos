# Use the slim Linux container

> This part has been moved to  <https://wasmedge.org/docs/develop/deploy/using-wasmedge-in-docker>. Please use our new docs.
