# Kwasm

This part has been moved to <https://wasmedge.org/docs/develop/deploy/kubernetes/kwasm>. Please use our new docs.
