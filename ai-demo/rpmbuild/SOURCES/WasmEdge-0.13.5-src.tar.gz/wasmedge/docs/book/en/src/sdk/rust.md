# WasmEdge Rust SDK

> This part has been moved to  <https://wasmedge.org/docs/embed/rust/intro>. Please use our new docs.
