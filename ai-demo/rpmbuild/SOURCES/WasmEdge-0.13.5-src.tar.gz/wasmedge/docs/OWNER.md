# Owners

## WasmEdge Maintainers

| Maintainer               | GitHub ID     | Organization                                  | Email                        |
| ---------------          | ---------     | -----------                                   | -----------                  |
| Michael Yuan             | @juntao       | Second State                                  | <michael@secondstate.io>     |
| Hung-Ying Tai(hydai)     | @hydai        | Second State                                  | <hydai@secondstate.io>       |
| Yi-Ying He               | @q82419       | Second State                                  | <yiying@secondstate.io>      |
| Shen-Ta Hsieh(BestSteve) | @ibmibmibm    | Second State                                  | <beststeve@secondstate.io>   |

## WasmEdge Committers

| Committers               | GitHub ID     | Organization                                  | Email                        |
| ---------------          | ---------     | -----------                                   | -----------                  |
| dm4                      | @dm4          | Second State                                  | <dm4@secondstate.io>         |
| yi                       | @0yi0         | Second State                                  | <yi@secondstate.io>          |
| Sam                      | @apepkuss     | Second State                                  | <sam@secondstate.io>         |
| danny                    | @dannypsnl    | Second State                                  | <dannypsnl@secondstate.io>   |
| Shreyas Atre             | @SAtacker     | SRA VJTI                                      | <shreyasatre16@gmail.com>    |

## WasmEdge Reviewers

| Reviewers                | GitHub ID     | Organization                                  | Email                        |
| ---------------          | ---------     | -----------                                   | -----------                  |
| 叶坚白                   | @gusye1234    | University of Science and Technology of China | <jianbaiye@outlook.com>      |
| Tricster                 | @MediosZ      | Southeast University                          | <mediosrity@gmail.com>       |
| Wenshuo Yang             | @sonder-joker | Bytedance                                     | <highmagic@outlook.com>      |
| csh                      | @L-jasmine    | Second State                                  | <458761603@qq.com>           |
| Amun                     | @hangedfish   | Giant Network Group Co., Ltd.                 | <bravohangedman@outlook.com> |
| yb                       | @yanghaku     | Nanjing University                            | <bo.yang@smail.nju.edu.cn>   |
| WenYuan Huang            | @michael1017  | Purdue University                             | <huan2086@purdue.edu>        |
