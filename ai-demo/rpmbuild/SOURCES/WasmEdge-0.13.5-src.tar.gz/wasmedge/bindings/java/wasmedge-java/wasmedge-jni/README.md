### Build and install
- Clone this project
- Go to `WasmEdge/bindings/java/wasmedge-jni`
- Run `mkdir build && cd build`
- Run `cmake .. && make && make install` 

