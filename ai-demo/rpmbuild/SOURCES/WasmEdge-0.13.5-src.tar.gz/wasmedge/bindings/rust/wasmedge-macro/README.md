# Overview

** `wasmedge-mcaro` is under [wasmedge-rust-sdk/crates/wasmedge-mcaro](https://github.com/WasmEdge/wasmedge-rust-sdk/tree/main/crates/wasmedge-mcaro) now. **

The [wasmedge-macro](https://crates.io/crates/wasmedge-macro) crate defines a group of procedural macros used by both [wasmedge-sdk](https://crates.io/crates/wasmedge-sdk) and [wasmedge-sys](https://crates.io/crates/wasmedge-sys) crates.

See also

* [WasmEdge Runtime](https://wasmedge.org/)
