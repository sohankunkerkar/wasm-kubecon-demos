# Overview

** `wasmedge-types` is under [wasmedge-rust-sdk/crates/wasmedge-types](https://github.com/WasmEdge/wasmedge-rust-sdk/tree/main/crates/wasmedge-types) now. **

The [wasmedge-types](https://crates.io/crates/wasmedge-types) crate defines a group of common data structures used by both [wasmedge-sdk](https://crates.io/crates/wasmedge-sdk) and [wasmedge-sys](https://crates.io/crates/wasmedge-sys) crates.

See also

* [WasmEdge Runtime](https://wasmedge.org/)
