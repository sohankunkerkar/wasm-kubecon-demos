# Overview

** `wasmedge-sdk` is moved to [wasmedge-rust-sdk](https://github.com/WasmEdge/wasmedge-rust-sdk)

The [wasmedge-sdk](https://crates.io/crates/wasmedge-sdk) crate defines a group of high-level Rust APIs, which are used to build up business applications.

* Notice that [wasmedge-sdk](https://crates.io/crates/wasmedge-sdk) requires **Rust v1.66 or above** in the **stable** channel.
