use wasi_logging_example::{
  wasi_logging_demo,
};

fn main() {
  wasi_logging_demo();
}