args = args.slice(1)
print("Hello",...args)